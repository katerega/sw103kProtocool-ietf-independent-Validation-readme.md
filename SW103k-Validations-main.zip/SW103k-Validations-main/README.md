SW103K Independent Validation Framework

Project: SW103K Transport and Compression Protocol  
Organisation: Chazah Group  
Validation architecture: Independent VPS1 → VPS2 testing  
Protocol port: TCP 10300 (subject to implementation verification)  
Status: Independent validation in progress

Repository: https://github.com/katerega/SW103k-Validations



 1. Purpose

This repository provides a reproducible framework for independently evaluating the SW103K protocol against conventional TCP transfers.

The objective is to establish, through independently reproducible experiments, whether SW103K improves:

1. Network bandwidth utilisation.
2. Data compression efficiency.
3. Persistent storage efficiency.
4. Transfer throughput.
5. Data integrity and reliability.
6. CPU and processing efficiency.

The framework is designed to allow an independent engineer to deploy two Linux VPS machines, execute the sender and receiver procedures, and produce verifiable experimental evidence.

No performance improvement is assumed. All claims must be established through measured results.

 2. Validation architecture

Two independently operated VPS machines are used.

| Machine | Role | Provider |
|---|---|---|
| VPS1 | Sender and test initiator | Contabo |
| VPS2 | Receiver, decompression and evidence collection | AfriCloud |

 Data flow

VPS1 generates and verifies the test datasets, initiates the SW103K transfer and records the transmitted data.

VPS2 receives the transfer, persists the received archives, performs the required decompression and verifies the restored files.

VPS2 must confirm successful persistence before the sender initiates any decompression trigger that requires a separate protocol operation.

The final validation report must contain evidence from both machines.

 3. Standard filesystem layout

The deployment should use the following filesystem locations:

| Directory | Purpose |
|---|---|
| `/opt/swk103/` | Executables and application files |
| `/etc/swk103/` | Configuration |
| `/var/lib/swk103/` | Persistent application data |
| `/var/log/swk103/` | Application logs |
| `/var/lib/swk103/evidence/` | Validation evidence |

The deployment scripts should create these directories where necessary and apply appropriate ownership and permissions.

The repository should retain its source structure separately from the installed application.

 4. Repository requirements

Both VPS machines must receive the complete validation repository.

The following components must be preserved:


SW103K-Eric-Validation/
├── VPS1/
│   ├── 01_prepare_source.sh
│   └── 03_run_client.sh
├── VPS2/
│   ├── run_receiver.sh
│   └── 02_collect_receiver.sh
├── bin/
│   └── libsw103k_codec.so
├── scripts/
│   └── two_vps.py
├── test-data/
├── evidence/
│   └── source-snapshot/
└── README.md


This is the required logical layout. Actual filenames and paths must be checked against the committed repository before deployment.

 System prerequisites

Both VPS machines must have:

- Compatible Linux architectures.
- Compatible SW103K codec library and runtime dependencies.
- Python 3 if the Python components are used.
- Required execution permissions.
- Sufficient disk space for test datasets and evidence.

VPS2 must permit inbound TCP traffic on port 10300, subject to confirmation of the actual receiver configuration.

 5. Two-command validation workflow

The primary operational interface is one receiver command on VPS2 and one sender command on VPS1.

 Command 1 — VPS2: Start receiver

Connect to VPS2 and execute:


cd ~/SW103K-Eric-Validation

sudo ./VPS2/run_receiver.sh


The receiver startup procedure should:

1. Identify the Linux architecture.
2. Check required dependencies.
3. Verify the SW103K codec library.
4. Verify the license service if required by the implementation.
5. Start the actual SW103K receiver.
6. Bind to the configured receiver interface.
7. Verify that TCP port 10300 is listening.
8. Display receiver readiness.
9. Record startup logs and timestamps.

Verify the listening socket:


sudo ss -lntp | grep 10300


Expected result: an active listening socket on the configured receiver port.

The receiver should also display its evidence and log locations.

Command 2 — VPS1: Initiate validation

Connect to VPS1 and execute:


cd ~/SW103K-Eric-Validation

./VPS1/01_prepare_source.sh

./VPS1/03_run_client.sh VPS2_PUBLIC_IP


Replace `VPS2_PUBLIC_IP` with the actual public IP address of VPS2.

The source preparation script should:

1. Generate or prepare the test datasets.
2. Verify source-file existence.
3. Record original file sizes.
4. Calculate SHA-256 checksums.
5. Record the test configuration.

The client should:

1. Verify the source files.
2. Calculate and record SHA-256 hashes.
3. Connect to VPS2.
4. Initiate the SW103K transfer.
5. Record transmitted protocol bytes.
6. Record transfer duration.
7. Obtain receiver persistence confirmation.
8. Initiate decompression where required.
9. Verify the restored files against the original hashes.
10. Generate a PASS/FAIL validation report.


 6. Alternative Python interface

The repository also contains a proposed Python-based interface:

Receiver:


python3 scripts/two_vps.py receive \
    --bind 0.0.0.0 \
    --port 10300


Sender:

```bash
python3 scripts/two_vps.py send \
    --host VPS2_PUBLIC_IP \
    --port 10300
```

These commands are an alternative interface, not an additional mandatory test procedure.

Use them only if the committed implementation supports these exact arguments and they invoke the same SW103K receiver and sender implementation as the shell scripts.

The shell scripts remain the authoritative interface for the documented two-command workflow.

7. Test datasets

Three traffic profiles are required.

| Profile | Dataset composition | Purpose |
|---|---|---|
| Text | Repeated text, JSON and CSV records | Evaluate compression of repetitive data |
| Mixed | Text, JSON, logs and binary blocks | Evaluate typical application traffic |
| Binary | Images, random bytes and other incompressible data | Evaluate framing and transmission overhead |

Each dataset must have a recorded original size and SHA-256 checksum.

The datasets must be identical for the SW103K and TCP baseline experiments.

8. Baseline TCP comparison

A conventional TCP transfer must be performed using the same:

- VPS1 and VPS2 machines.
- Network route.
- Source datasets.
- Test file sizes.
- Measurement methodology.
- Receiver storage conditions.

Both experiments must record:

1. Original payload size.
2. Actual network bytes transmitted.
3. Actual received bytes.
4. Actual persistent storage consumption.
5. Transfer duration.
6. Throughput.
7. CPU consumption.
8. SHA-256 integrity verification.

Protocol overhead, acknowledgements, retransmissions and other network traffic must be accounted for consistently.

Do not equate compressed payload size with actual network bandwidth consumption.

9. Required measurements

#A. Bandwidth efficiency

Record actual bytes transferred across the network.

Calculate:

```text
Bandwidth Reduction (%) =

((TCP Network Bytes - SW103K Network Bytes)
 / TCP Network Bytes) × 100
```

#B. Storage efficiency

Measure actual persistent storage consumption on VPS2.

Calculate:

```text
Storage Reduction (%) =

((TCP Stored Bytes - SW103K Stored Bytes)
 / TCP Stored Bytes) × 100
```

#C. Compression ratio

```text
Compression Ratio =

Original Payload Bytes / Compressed Payload Bytes
```

#D. Throughput

```text
Throughput =

Original Payload Bytes / Transfer Duration
```

Use consistent units and report whether throughput is measured at the application or network layer.

#E. Integrity

For every dataset:

```text
Original SHA-256 == Restored SHA-256
```

All three datasets must pass integrity verification.

10. Evidence collection

Evidence must be collected from both VPS machines.

#VPS1 — Sender evidence

- Source dataset inventory.
- Original file sizes.
- Original SHA-256 hashes.
- Network transfer measurements.
- Transfer duration.
- Sender logs.
- Test configuration.
- Sender execution timestamps.

#VPS2 — Receiver evidence

- Receiver startup logs.
- Listening port confirmation.
- Received archive inventory.
- Actual persistent storage measurements.
- Decompression results.
- Restored file sizes.
- Restored SHA-256 hashes.
- Receiver execution timestamps.

#Evidence integrity

Evidence files should be timestamped and retained without overwriting earlier test runs.

Each test run should have a unique identifier.

The final report should reference the corresponding sender and receiver evidence files.

11. Testing sequence

The validation process must follow this order.

Phase 1 — Implementation verification

- Confirm the actual SW103K sender implementation.
- Confirm the actual SW103K receiver implementation.
- Verify the codec library.
- Verify dependencies and licensing requirements.
- Confirm the protocol port and configuration.
- Confirm that both command interfaces invoke the intended implementation.

Phase 2 — Deployment preparation

- Prepare VPS1 and VPS2.
- Copy the complete repository to both machines.
- Confirm compatible architectures.
- Configure the firewall.
- Confirm receiver readiness.
- Confirm evidence directory permissions.

Phase 3 — Small independent transfer

- Start VPS2 receiver.
- Prepare the source datasets on VPS1.
- Initiate the transfer.
- Confirm receiver persistence.
- Perform decompression.
- Verify SHA-256 integrity.
- Collect logs and measurements.

Phase 4 — TCP baseline

- Transfer identical datasets using conventional TCP.
- Measure network bytes and actual storage consumption.
- Record transfer time and CPU usage.
- Verify data integrity.

Phase 5 — Comparative analysis

- Compare SW103K against TCP.
- Calculate bandwidth reduction.
- Calculate storage reduction.
- Calculate compression ratios.
- Compare throughput and CPU overhead.
- Document limitations and failures.

Phase 6 — Larger-scale validation

Only after the small independent transfer succeeds should larger datasets be introduced.

The 10 GB test must not be attempted until the small transfer, persistence, decompression and SHA-256 verification have all passed.

12. Acceptance criteria

The independent validation is considered successful only when:

| Requirement | Acceptance criterion |
|---|---|
| Receiver startup | VPS2 reports ready |
| Network connectivity | VPS1 connects to VPS2 |
| SW103K transfer | Actual protocol transfer completes |
| Persistence | VPS2 confirms received archives are stored |
| Decompression | Restored files are produced successfully |
| Text integrity | SHA-256 PASS |
| Mixed integrity | SHA-256 PASS |
| Binary integrity | SHA-256 PASS |
| TCP baseline | Comparable measurements available |
| Bandwidth measurements | Actual network bytes recorded |
| Storage measurements | Actual disk usage recorded |
| Evidence | Sender and receiver logs preserved |

A successful connection alone does not constitute a successful validation.

A successful transfer alone does not establish compression efficiency.

Performance improvements must be supported by measured comparisons against the TCP baseline.

13. Independent validation status

The current objective is to complete a reproducible VPS1-to-VPS2 experiment:

- VPS1 (Contabo): sends the three datasets.
- VPS2 (AfriCloud): receives and stores the compressed archives.
- VPS2 confirms persistence before decompression is initiated.
- VPS2 verifies the restored files.
- Both machines produce independently inspectable evidence.

The validation report must not describe the independent VPS test as PASSED until the actual outputs from both machines have been collected and verified.

No bandwidth or storage efficiency claim should be treated as independently established until the corresponding measurements have been reproduced.

14. Technical review and contributions

Independent engineers and researchers are invited to:

- Review the implementation.
- Inspect the test methodology.
- Reproduce the experiments.
- Identify implementation weaknesses.
- Challenge the compression and bandwidth measurements.
- Suggest improvements to the benchmarking methodology.
- Submit independently generated test results.

The objective is transparent technical evaluation rather than promotional endorsement.

SW103K — Independent, reproducible and evidence-based protocol validation.

Chazah Group Ltd
